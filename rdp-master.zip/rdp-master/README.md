

## Free RDP 6 HOURS

it's all free, don't be stingy ⭐️ yes: D

### HOW TO CREATE netslutter-RDP
```
> Press the Fork button to create RDP (For Android / HP Users, Please Use Desktop Mode).

> visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN

> Inside this Repo Go to Settings> Secrets> New repository secret

> Fill in the Name: Enter NGROK_AUTH_TOKEN

> Fill in Value: Visit https://dashboard.ngrok.com/auth/your-authtoken Copy and Paste in the value

> Press Add secret 

> Go to Action> CI> Run workflow

> Refresh Web and go to CI> build

> Press Down facing arrow button "RDP INFO LOGIN" To Get IP, User, Password.
```
## If Error Showed

Just Download This Whole repository And make new repo in your GitHub account and upload all the files
### WARN

THIS IS ONLY FOR EDUCATIONAL PURPOSES

DON'T USE FOR MINING OR ILLEGAL USE

DON'T RECODE THIS SC!.
